import React, { useState, useEffect } from "react";
import axios from "axios";
import moment from "moment";
import ReactPaginate from "react-paginate";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const SuperAdminTotalClosedDealContent = () => {
  const [leads, setLeads] = useState([]);
  const [filteredLeads, setFilteredLeads] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [leadsPerPage, setLeadsPerPage] = useState(7);
  const navigate = useNavigate();
  const superadminuser = useSelector((state) => state.auth.user);
  const token = superadminuser.token;
  const userId = superadminuser.id;

  useEffect(() => {
    fetchLeads();
  }, []);

  const fetchLeads = async () => {
    try {
      const response = await axios.get(
        `https://crm-generalize.dentalguru.software/api/leads-super-admin/${userId}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const nonPendingLeads = response.data.filter(
        (lead) => lead.deal_status == "close"
      );
      setLeads(nonPendingLeads);
      setFilteredLeads(nonPendingLeads);
    } catch (error) {
      console.error("Error fetching leads:", error);
    }
  };

  useEffect(() => {
    let filtered = leads;

    // Filter by search term
    if (searchTerm) {
      const trimmedSearchTerm = searchTerm.toLowerCase().trim();
      filtered = filtered.filter((lead) =>
        ["name", "leadSource", "phone", "assignedTo"].some((key) =>
          lead[key]?.toLowerCase().trim().includes(trimmedSearchTerm)
        )
      );
    }

    // Update the filtered leads and reset to the first page
    setFilteredLeads(filtered);
    setCurrentPage(0); // Reset to the first page when the search term changes
  }, [searchTerm, leads]);

  // Pagination logic
  const pageCount = Math.ceil(filteredLeads.length / leadsPerPage);
  const indexOfLastLead = (currentPage + 1) * leadsPerPage;
  const indexOfFirstLead = indexOfLastLead - leadsPerPage;
  // const currentLeads = filteredLeads.slice(indexOfFirstLead, indexOfLastLead);
  const currentLeads =
    leadsPerPage === Infinity
      ? filteredLeads
      : filteredLeads.slice(indexOfFirstLead, indexOfLastLead);

  const handlePageClick = (data) => {
    setCurrentPage(data.selected);
    console.log("change current page ", data.selected);
  };
  const handleLeadsPerPageChange = (e) => {
    const value = e.target.value;
    setLeadsPerPage(value === "All" ? Infinity : parseInt(value, 10));
    setCurrentPage(0); // Reset to the first page
  };
  return (
    <>
      <div className="flex mt-20">
        <div className="w-full min-h-screen bg-[#F9FAFF] p-2">
          <div>
            <div className="container mt-[2rem]  ">
              <button
                onClick={() => navigate(-1)}
                className="bg-cyan-600 text-white px-3 py-1 max-sm:hidden rounded-lg hover:bg-cyan-700 transition-colors"
              >
                Back
              </button>
            </div>
            <div className="flex flex-col">
              <div className="flex-grow p-4 mt-2  sm:ml-0">
                <center className="text-2xl text-center  font-medium">
                  Total Closed Deals
                </center>
                <center className="mx-auto h-[3px] w-16 bg-cyan-600 my-3"></center>
                <div className="flex justify-between mb-2">
                  <input
                    type="text"
                    placeholder="Search by Name, Lead Source, Assigned To, Phone No...."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border rounded-md p-2 w-2/4"
                  />
                  <select
                    onChange={handleLeadsPerPageChange}
                    className="border rounded-md p-2 w-1/4"
                  >
                    <option value={7}>Number of rows: 7</option>
                    <option value={10}>10</option>
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                    <option value="All">All</option>
                  </select>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full bg-white border">
                    <thead>
                      <tr>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          S.no
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Lead Id
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Assigned To
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Lead Name
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Phone
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Lead Source
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Visit
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Follow Up Status
                        </th>

                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Deal Status
                        </th>
                        <th className="px-6 py-3 border-b-2 border-gray-300 whitespace-nowrap text-cyan-700 font-bold text-sm">
                          Deal Close Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentLeads.length > 0 ? (
                        currentLeads.map((lead, index) => (
                          <tr
                            key={lead.id}
                            className={index % 2 === 0 ? "bg-gray-100" : ""}
                          >
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {leadsPerPage === Infinity
                                ? index + 1
                                : index + 1 + currentPage * leadsPerPage}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.lead_id}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.assignedTo}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.name}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.phone}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.leadSource}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.visit}
                            </td>

                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.follow_up_status}
                            </td>

                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {lead.deal_status}
                            </td>
                            <td className="px-6 py-4 border-b border-gray-200 text-gray-800">
                              {}
                              {moment(lead.d_closeDate)
                                .format("DD MMM YYYY")
                                .toUpperCase()}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={11} className="py-4 text-center">
                            No data found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="mt-2 mb-2 flex justify-center">
                  <ReactPaginate
                    previousLabel={"Previous"}
                    nextLabel={"Next"}
                    breakLabel={"..."}
                    pageCount={pageCount}
                    forcePage={currentPage}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={3}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    activeClassName={"active"}
                    pageClassName={"page-item"}
                    pageLinkClassName={"page-link"}
                    previousClassName={"page-item"}
                    nextClassName={"page-item"}
                    previousLinkClassName={"page-link"}
                    nextLinkClassName={"page-link"}
                    breakClassName={"page-item"}
                    breakLinkClassName={"page-link"}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SuperAdminTotalClosedDealContent;
