import { useState, useEffect } from "react";
import axios from "axios";
import { useSelector } from "react-redux";

const SuperFormSelector = ({
  setLoading,
  setMe,
  setError,
  id,
  onFormSelect,
}) => {
  const [forms, setForms] = useState([]);
  const [selectedFormId, setSelectedFormId] = useState("");
  const [selectedFormName, setSelectedFormName] = useState("");
  const superadminuser = useSelector((state) => state.auth.user);
  const token = superadminuser.token;

  // Fetch forms from backend
  const fetchForms = async () => {
    try {
      const response = await axios.get(
        `https://crm-generalize.dentalguru.software/api/forms/${id}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setForms(response.data.reverse());
    } catch (err) {
      console.error("Error fetching forms:", err);
      setError("Failed to fetch forms");
    }
  };

  // Handle form selection change
  const handleFormChange = (e) => {
    const formId = e.target.value;
    const formName = forms.find((form) => form.form_id === formId)?.form_name;

    setMe(formId);
    setSelectedFormId(formId);
    setSelectedFormName(formName);
    onFormSelect(formId, formName);
  };

  // Handle fetch leads button click
  const handleFetchLeads = async () => {
    if (!selectedFormId) {
      setError("Please select a form");
      return;
    }

    setLoading(true);
    setError("Wait");

    try {
      // Fetch leads from Meta API via backend
      const response = await axios.post(
        "https://crm-generalize.dentalguru.software/api/leads/fetch",
        {
          formId: selectedFormId,
        }
      );
      setError("Fetch leads Done");
      setLoading(false);
    } catch (err) {
      console.error("Error fetching leads:", err);
      setError("Failed to fetch leads");
      setLoading(false);
    }
  };

  // fetchForms();
  useEffect(() => {
    fetchForms();
  }, []);

  return (
    <div className="mb-4">
      <label className="block text-gray-700 text-sm font-bold mb-2">
        Select a Form
      </label>
      <select
        onChange={handleFormChange}
        className="border rounded w-full py-2 px-3 text-gray-700"
        value={selectedFormId}
      >
        <option value="">-- Select a Form --</option>
        {forms.map((form) => (
          <option key={form.id} value={form.form_id}>
            {form.form_name} (ID: {form.form_id})
          </option>
        ))}
      </select>
    </div>
  );
};

export default SuperFormSelector;
