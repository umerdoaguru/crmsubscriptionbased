import axios from "axios";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import ReactPaginate from "react-paginate";

const SuperAdminTotalLeadContent = () => {
  const [leads, setLeads] = useState([]);
  const [filteredLeads, setFilteredLeads] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [leadsPerPage, setLeadsPerPage] = useState(10);
  const navigate = useNavigate();
  const superadminuser = useSelector((state) => state.auth.user);
  const token = superadminuser.token;
  const userId = superadminuser.staff_id;
  useEffect(() => {
    fetchLeads();
  }, []);

  const fetchLeads = async () => {
    try {
      const response = await axios.get(
        `https://crm-generalize.dentalguru.software/api/getLeadsByOrg/${superadminuser?.staff_org_id}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log(response);
      setLeads(response.data);
    } catch (error) {
      console.error("Error fetching leads:", error);
    }
  };

  console.log(leads);

  useEffect(() => {
    let filtered = leads;

    if (searchTerm) {
      const trimmedSearchTerm = searchTerm.toLowerCase().trim();
      filtered = filtered.filter((lead) =>
        ["name", "leadSource", "phone", "assignedTo"].some((key) =>
          lead[key]?.toLowerCase().trim().includes(trimmedSearchTerm)
        )
      );
    }

    setFilteredLeads(filtered);
    setCurrentPage(0);
  }, [searchTerm, leads]);

  // Pagination logic
  const pageCount = Math.ceil(filteredLeads.length / leadsPerPage);
  const indexOfLastLead = (currentPage + 1) * leadsPerPage;
  const indexOfFirstLead = indexOfLastLead - leadsPerPage;
  const currentLeads =
    leadsPerPage === Infinity
      ? filteredLeads
      : filteredLeads.slice(indexOfFirstLead, indexOfLastLead);

  const handlePageClick = (data) => {
    setCurrentPage(data.selected);
    console.log("change current page ", data.selected);
  };
  const handleLeadsPerPageChange = (e) => {
    const value = e.target.value;
    setLeadsPerPage(value === "All" ? Infinity : parseInt(value, 10));
    setCurrentPage(0);
  };

  return (
    <>
      <div className="flex mt-20">
        <div className="w-[90%] sm:w-full min-h-screen bg-[#F9FAFF] p-2">
          <div>
            <div className="container  mt-[2rem]">
              <div className="">
                <button
                  onClick={() => navigate(-1)}
                  className="bg-cyan-600 text-white px-3 py-1 max-sm:hidden rounded-lg hover:bg-cyan-700 transition-colors"
                >
                  Back
                </button>
              </div>
              <h2 className="text-2xl text-center ">Total Leads</h2>
              <div className="mx-auto h-[3px] w-16 bg-cyan-600 my-3"></div>
            </div>
            <div className=" px-2 ">
              <div className="flex justify-between mb-3">
                <input
                  type="text"
                  placeholder="Search by Name, Lead Source, Assigned To, Phone No..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="border rounded-md p-2 w-2/4"
                />

                <select
                  onChange={handleLeadsPerPageChange}
                  className="border rounded-md p-2 w-1/4"
                >
                  <option value={7}>Number of rows: 7</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value="All">All</option>
                </select>
              </div>
            </div>

            <div className="main overflow-x-auto mt-4 px-2 ">
              <table className="bg-white border w-100">
                <thead>
                  <tr>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      S.no
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Lead Id
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Name
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Phone
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Lead Source
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Assigned To
                    </th>

                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Lead Status
                    </th>
                    <th className="px-2 py-3 border-b-2 border-gray-300 text-left leading-4 text-gray-600 tracking-wider">
                      Assigned Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currentLeads.map((lead, index) => (
                    <tr
                      key={lead.lead_id}
                      className={index % 2 === 0 ? "bg-gray-100" : ""}
                    >
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {leadsPerPage === Infinity
                          ? index + 1
                          : index + 1 + currentPage * leadsPerPage}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200">
                        {lead.lead_id}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {lead.name}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {lead.phone}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {lead.leadSource}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {lead.staff_name}
                      </td>

                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {lead.lead_status}
                      </td>
                      <td className="px-2 py-4 border-b border-gray-200 text-gray-800">
                        {moment(lead.createdTime)
                          .format("DD MMM YYYY")
                          .toUpperCase()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <>
              <div className="mt-2 mb-2 flex justify-center">
                <ReactPaginate
                  previousLabel={"Previous"}
                  nextLabel={"Next"}
                  breakLabel={"..."}
                  pageCount={pageCount}
                  forcePage={currentPage}
                  marginPagesDisplayed={2}
                  pageRangeDisplayed={3}
                  onPageChange={handlePageClick}
                  containerClassName={"pagination"}
                  activeClassName={"active"}
                  pageClassName={"page-item"}
                  pageLinkClassName={"page-link"}
                  previousClassName={"page-item"}
                  nextClassName={"page-item"}
                  previousLinkClassName={"page-link"}
                  nextLinkClassName={"page-link"}
                  breakClassName={"page-item"}
                  breakLinkClassName={"page-link"}
                />
              </div>
            </>
          </div>
        </div>
      </div>
    </>
  );
};

export default SuperAdminTotalLeadContent;
